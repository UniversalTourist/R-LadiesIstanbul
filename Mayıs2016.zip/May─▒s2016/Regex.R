# Data Cleaning - Regular Expressions
require("lubridate")
require("stringr")

# "" ve '' farkı
# MyString.1 <- "My string is "bla bla" "
# MyString.2 <- "My string is 'bla bla' "

# Numerik deger icerir ama karakter dondurur,
CharVector <- c("2",1:5,rep(10,4))
CharVector

# character tip,
character(length = 1)

#Fonksiyonlar (USArrests dataset)
?USArrests
attach(USArrests)
data("USArrests")
  
#Slayt 11
  # states etiketleri,
  states <- row.names(USArrests)
  
  # as, is
  is.character(states)
  states <- as.character(states)
  
  # paste()
  paste("Bugün günlerden",weekdays(Sys.Date()))
  
  # cat()
  cat("Bugün günlerden",weekdays(Sys.Date()),"\n")
  
  # format()
  format(pi,digits = 22)
    
  # sprintf()
  sprintf("Bugün günlerden: %s",weekdays(Sys.Date()))
  
  # Slayt 11 Ornek,
  #pdf("USArrests_Metrikleri.pdf",width = 16,height = 5)
  for(IndColName in colnames(USArrests)){
    
    USArrestsOrdered <- USArrests[order(USArrests[colnames(USArrests)%in%IndColName]),]
    state.names = row.names(USArrestsOrdered)
    
    barplot(USArrestsOrdered[,IndColName], 
            names.arg = state.names, 
            las = 2,
            ylab = IndColName, 
            main = paste("Eyaletlere Göre", IndColName, "Degerleri",sep=" "),
            cex.names = 0.7)
    cat(IndColName,"grafigi ciziliyor","\n")
  }
  
  #dev.off()
  
#Slayt 12
  
  # nchar()
  nchar(states)
  
  # tolower()
  tolower(states)
  
  # toupper()
  toupper(states)
  
  # substr()
  substr(states, start = 2, stop = 8)
  substr(states, start = 1, stop = which.max(nchar(states)))  
  
  statesCopy <- states 
  substr(statesCopy, start = 2, stop = 3) <- "@"
  print(statesCopy)  
  
  # sort()
  sort(states,decreasing = FALSE)

  # rep()
  rep(states,each=3)

#Slayt 13

  # str_c() =~ cat() =~ paste()
  str_c("Bugün günlerden ",weekdays(Sys.Date()))
  str_c(states,"Eyaletinin Murder Degeri :",USArrests$Murder)
  
  # str_length() =~ nchar()
  str_length(states)
  
  # str_sub() =~ substr()
  str_sub(states[1], start = 1, end = 5)
  str_sub(states[1], 1:str_length(states[1]))
  
  # str_pad()
  states[1]
  str_pad(states[1], width = 11,side = "left")
  str_pad(states[1], width = 11,side = "both",pad = "+")

  # str_trim()
  AlabamaTrim <- str_c("  ",states[1],"   ")
  str_trim(AlabamaTrim,side = "left")
  str_trim(AlabamaTrim,side = "right")
  str_trim(AlabamaTrim,side = "both")
  
  # word()
  WordList <- c(str_c(states[1],states[2], sep = " "),states[3])
  WordList
  word(WordList, 1)
  
#Slayt 15
  # grep()
  grep("Alabama",states)
  grep("Alabama",states,value = TRUE)
  
  # grepl()
  grepl("Alabama",states)
  
  # sub()
  sub("a","@@@",states)
  
  # gsub()
  gsub("a","@@@",states)
  
#Regex Ornekleri

  # Sequences
  stringsS <- c("^abs", "33abSSS", "22abc  ", "  abd  ","22","abh")
  gsub("\\d","", stringsS)
  gsub("\\D","", stringsS)
  gsub("\\s","", stringsS)
  gsub("\\S","", stringsS)
  gsub("\\w","", stringsS)
  gsub("\\W","", stringsS)
  
  # Quantifiers
  stringsQ <- c("a", "ab", "acb", "accb", "acccb", "accccb")
  grep("ac*b", stringsQ, value = TRUE)
  grep("ac+b", stringsQ, value = TRUE)
  grep("ac?b", stringsQ, value = TRUE)
  grep("ac{2}b", stringsQ, value = TRUE)
  grep("ac{2,}b", stringsQ, value = TRUE)
  grep("ac{2,3}b", stringsQ, value = TRUE)
  
  # Pozisyon belirtecleri,
  stringsP <- c("abcd", "cdab", "cabd", "c abd")
  grep("ab", stringsP, value = TRUE)
  grep("^ab", stringsP, value = TRUE)
  grep("ab$", stringsP, value = TRUE)
  
  # Character Classes
  stringsC <- c("^ab", "ab", "abc", "abd", "abe")
  grep("ab[c-e]", stringsC, value = TRUE)
  grep("ab[^c]", stringsC, value = TRUE)
  grep("^ab", stringsC, value = TRUE)
  grep("\\^ab", stringsC, value = TRUE)
  grep("abc|abd", stringsC, value = TRUE)
  
  # POSIX Characters
  stringsPosix <- c("^ab", "bac", "ss4", "442", "DDdd!:33")
  grep("[[:digit:]]", stringsPosix, value = TRUE)
  grep("[[:upper:]]", stringsPosix, value = TRUE)
  grep("[[:alpha:]]", stringsPosix, value = TRUE)
  grep("[[:alnum:]]", stringsPosix, value = TRUE)
  
    
# E-mail check ornegi 
  emailPath <- "^([a-z0-9_\\.-]+)@([a-z\\.-]+)\\.([a-z\\.]{2,6})$"

  grep(emailPath, "rladiesistanbul@gmail.com",value = TRUE)
  grep(emailPath, "rladies_istanbul.34@gmail.com",value = TRUE)

  # Username check ornegi
  usernamePath <- "^[a-zA-Z0-9_-]{3,16}$"
  grep(usernamePath, "rladies_Istanbul",value = TRUE)
  nchar("rladies_Istanbul")
  grep(usernamePath, "rladies_Istanbul_Fun",value = TRUE)