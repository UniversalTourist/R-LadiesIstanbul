rm(list=ls());gc();
require(data.table)
require(zoo)
require(lubridate)
require(forecast)
require(tsoutliers)

simdiZaman=Sys.time()
str(simdiZaman)
year(simdiZaman)
month(simdiZaman)
day(simdiZaman)
second(simdiZaman)

#Base R'dan
weekdays(simdiZaman)
months(simdiZaman)

#Herhangi bir karakter vektörü için
karakterZaman=as.character(simdiZaman)
posixltZaman=strptime(karakterZaman,"%Y-%m-%d %H:%M:%S")
str(posixltZaman)
posixltZaman$sec
posixltZaman$hour
posixltZaman$mday #ayın kaçıncı günü
posixltZaman$yday #yılın kaçıncı günü
posixltZaman$wday #haftanın kaçıncı günü, Pazar=0, Pzt=1, ...
posixltZaman$mon
posixltZaman$year #1900 den bu zaman kadar geçen yıl sayısı

#sadece tarihi saklamak istersek
tarih=format(posixltZaman,"%d/%m/%Y")
str(tarih)
tarih_date=as.Date(posixltZaman)
str(tarih_date)

setwd('C:/mustafa/Presentation/RLadies/')
talepVeri=fread('demand.csv')
str(talepVeri)

system.time(
	talepVeri[,Tarih_as_Date:=as.Date(Tarih)]
)

# strptime daha uzun sürüyor
#system.time(
#	talepVeri[,Tarih_as_Date:=strptime(Tarih,"%Y-%m-%d")]
#)

filtreVeri=talepVeri[Urun==259 & Magaza==2]

zooSerisi=zoo(filtreVeri[,list(Satis,Meblag)],filtreVeri$Tarih_as_Date)
nrow(filtreVeri)
length(zooSerisi)

filtreVeri[,OrtSatFiyat:=Meblag/Satis]
zooSerisi=zoo(filtreVeri[,list(Satis,OrtSatFiyat)],filtreVeri$Tarih_as_Date)

plot(zooSerisi)

#satis olmayan günlerde fiyat bilgisi yok
zooSerisi=na.locf(zooSerisi)
plot(zooSerisi)

zooSerisiHaftalik=zoo(filtreVeri[,list(Satis,Meblag)],filtreVeri$Tarih_as_Date)
yeniTarih=as.Date(7 * floor(as.numeric(time(zooSerisiHaftalik)) / 7))
zooSerisiHaftalik=aggregate(zooSerisiHaftalik, yeniTarih, sum)
plot(zooSerisiHaftalik)

zooSerisiHaftalik$Meblag=zooSerisiHaftalik$Meblag/zooSerisiHaftalik$Satis
plot(zooSerisiHaftalik)
zooSerisiHaftalik=na.locf(zooSerisiHaftalik)
plot(zooSerisiHaftalik)

#tsoutliers paketinden - zaman alabilir
anomali=tso(ts(zooSerisi$Satis),type=c('AO'),tsmethod='auto.arima')

#ya da basit bir yöntem
#parametreler
pencere=60
kantil=0.99
# eşik değeri belirleme
ut=function(x) {quantile(x,kantil)}
z=rollapply(zoo(zooSerisi$Satis), pencere, ut, align="right")
z=c(rep(z[1], pencere-1), z) #pencere seviyesine kadar olan için eşik yok
anomali = zooSerisi$Satis > z
plot(zoo(cbind(zooSerisi$Satis,anomali)))

