
# x11(width = 12, height = 10) # It opens a new page.

split.screen(c(2,2))  # This splits the screen into 4 parts.


screen(1) 

#nhtemp

temp<-(nhtemp-32)*5/9

plot(temp)


screen(2)


plot(temp,type = "l", col = 3, lwd = 2, lty = 1, ylim = c(6,15), axes = T, 
     xlab = "Years", ylab = "Temperature (?C)", main = "	Average Yearly Temperatures" )

screen(3)


mydata <- read.table(file = "/Users/hazelkavili/Desktop/introtoStatistics/aa.txt", sep = "")

plot(mydata$V1,type = "l", col = 3, lwd = 2, lty = 1, ylim = c(10,30), axes = T, 
     xlab = "Number of Days", ylab = "Temperature", main = "Temperature of Istanbul")


screen(4)

plot(mydata$V1,type = "l", col = 3, lwd = 2, lty = 1, ylim = c(10,30), axes = F, 
     xlab = "Number of Days", ylab = "Temperature", main = "Temperature of Istanbul")
box()

abline(h = max(mydata$V1),lwd = 2,lty = 2, col = 1)
abline(h = min(mydata$V1),lwd = 2,lty = 3, col = 2)

#abline(h = 0, lty = 2, col = "magenta")

axis(1,at = 1:100)
axis(2,at = 10:35)

legend(66,17, c("Mydata","Max","Min"), lty = c(1,2,3), col = c(3,1,2)) 

#labels= c("a","b","c","d","e","f","g","h", "I", "J", "K", "L", "M" ,"N" ,"O" ,"P", "Q", "R" ,"S" ,"T","a","b","c","d","e","f","g","h", "I", "J", "K", "L", "M" ,"N" ,"O" ,"P", "Q", "R" ,"S" ,"T","a","b","c","d","e","f","g","h", "I", "J", "K", "L", "M" ,"N" ,"O" ,"P", "Q", "R" ,"S" ,"T","a","b","c","d","e","f","g","h", "I", "J", "K", "L", "M" ,"N" ,"O" ,"P", "Q", "R" ,"S" ,"T","a","b","c","d","e","f","g","h", "I", "J", "K", "L", "M" ,"N" ,"O" ,"P", "Q", "R" ,"S" ,"T")




#http://www.statmethods.net/advgraphs/parameters.html

#https://www.r-bloggers.com/mastering-r-plot-part-2-axis/

#http://www.statmethods.net/graphs/line.html


