# Hazel Kavili 
# R-Ladies Istanbul: Intro to Statistics with R

# types of variables
# factor() for nominal variables. example of your survey
answers <- c(1, 2, 4, 6, 10)
factor_answers <- factor(answers)
class(factor_answers)

# assign an order to your nominal values, making them ordinal variables
# levels: desired level hierarchy to the argument 
temperature_vector <- c("High", "Low", "High", "Low", "Medium")
factor_temperature_vector <- factor(temperature_vector, order = TRUE, 
                                    levels = c("Low", "Medium", "High"))


mysample <- sample(1:2, 20, replace = TRUE)
factor_mysample <- factor(mysample, labels = c("iphone", "android"))
table(factor_mysample)

# histograms and distributions
install.packages('HistData')
library(HistData)

# normal distribution and hist function
hist(ChestSizes$chest, breaks = 4, col = "blue", 
     main = "Distribution of Chest Sizes",
     xlab = "Chest Size", ylab = "Frequency")


hist(AirPassengers)
hist(AirPassengers, 
    main="Histogram for Passengers", xlab="Passengers", 
    border="blue", col="green",
    xlim=c(100,700), las=1, 
    breaks=5)


hist(Galton$parent,main="Histogram for Weight of Parents", xlab="Weight", 
     border="grey", col="green")

# z-score
x <- sample(1:100, 15)
z <- (x - mean(x))/sd(x)
mean(z)
hist(z)
scale(x)
z == scale(x)

# central tendency measures and dispersion meausures
normalVar <- rnorm(100, mean = 3, sd = 1.5)
hist(normalVar, breaks = 5)
mean(normalVar)
sd(normalVar)
median(normalVar)

IQR(normalVar)
quantile(normalVar)
quantile(normalVar, 0.25)

Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))] #tabulate: 
}

# coefficient of variation
CV <- function(mean, sd) {
	(sd/mean) * 100
}

A <- c(4.0, 4.1, 4.3, 4.0, 4.1)
B <- c(7.3, -3.7, 8.4, -2.5, 11.0)

sd_A <- sd(A)
sd_B <- sd(B)
mean_A <- mean(A)
mean_B <- mean(B)

CV(mean=mean_A, sd=sd_A)
CV(mean_B, sd_B)

# or you can install raster package and run cv function
install.packages("raster")
library(raster)
cv(A)
cv(B)

######--------------------------Statistical Tests---------------------------------------##
# Statistical tests to compare means: t-test example
# Generate a vector of 100 values between -4 and 4
x <- seq(-4, 4, length = 100)

# Simulate the t-distribution
y_1 <- dt(x, df = 4) #df: degree of freedom
y_2 <- dt(x, df = 6)
y_3 <- dt(x, df = 8)
y_4 <- dt(x, df = 10)
y_5 <- dt(x, df = 12)

# Plot the t-distributions
plot(x, y_1, type = "l", lwd = 2, xlab = "t-value", ylab = "Density", 
     main = "Comparison of t-distributions", col = "black")
lines(x, y_2, col = "red")
lines(x, y_3, col = "orange")
lines(x, y_4, col = "green")
lines(x, y_5, col = "blue")

# Add a legend
legend("topright", c("df = 4", "df = 6", "df = 8", "df = 10", "df = 12"), 
       col = c("black", "red", "orange", "green", "blue"), 
       title = "t-distributions", lty = 1)

###------------Dependent t-test example------------#
# Import wm (working memmory) data set first
# Create training subset of wm
wm_t <- subset(wm, wm$train == "1")

# Summary statistics 
summary(wm_t)

# Create a boxplot with pre- and post-training groups 
boxplot(wm_t$pre, wm_t$post, main = "Boxplot", 
        xlab = "Pre- and Post-Training", ylab = "Intelligence Score", 
        col = c("red", "green"))

###------------Dependent t-test example------------#
# Define the sample size
n <- nrow(wm_t)

# Mean of the difference scores
mean_diff <- sum(wm_t$gain) / n

# Standard deviation of the difference scores
sd_diff <- sqrt(sum((wm_t$gain - mean_diff)^2) / (n - 1)) #why used (n-1) instead of n?

# Observed t-value
t_obs <- mean_diff / (sd_diff / sqrt(n))

# Print observed t-value
t_obs

###----------------
# Compute the critical value
# we choosed alpha = 0.05 and we decide 
t_crit <- qt(0.975, df = 79)  # (0.05/2) and (1-0.025), (80-1)

# Print the critical value
t_crit

# Print the observed t-value to compare 
t_obs

# Compute Cohen's d
cohens_d <- mean_diff / sd_diff 

# View Cohen's d
cohens_d


####---------with R functions------------
install.packages("lsr")
library(lsr)

#for t.test()
#x:column of wm_t containing "post-training" intelligence scores
#y:column of wm_t containing "pre-training" intelligence scores
#paired
t.test(wm_t$post, wm_t$pre, paired = TRUE)


#for cohensD()
#x:column of wm_t containing "post-training" intelligence scores
#y:column of wm_t containing "pre-training" intelligence scores
#method:Version of cohen's D compute, which should be "paired" in our case
cohensD(wm_t$post, wm_t$pre, method = "paired")



