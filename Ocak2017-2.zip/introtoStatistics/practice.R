# Hazel Kavili 
# R-Ladies Istanbul: Intro to Statistics with R
# Practice time!

# we have 2 datasets: battleHistory and soldiersByCity
summary(battleHistory)
summary(soldiersByCity)

soldiersByCity$Soldiers
attach(soldiersByCity)
attach(battleHistory)

hist(DurationInDays, main="Histogram for Duration in Days for Battle", 
     xlab="Duration in Days", 
     border="grey", col="yellow",
     xlim=c(0,200), las=1, 
     breaks=10)






