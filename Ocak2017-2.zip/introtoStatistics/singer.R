# BAR CHART
library(lattice)
data(singer)
attach(singer)
head(singer)
str(singer)
barchart(voice.part)
barchart(sort(table(voice.part)))
barchart(voice.part, horizontal = F)
barchart(sort(table(voice.part)), horizontal = F, main = "Ses Turleri", col = "purple")
barchart(sort(table(voice.part)), horizontal = F, main = "Ses Turleri",
 xlab = "Ses Turu", ylab = "Frekanslar", scales=list(alternating=1))  # eksen degistirme

# PIE CHART
pie(table(voice.part), main = "Ses Turleri")
pie(table(voice.part), main = "Ses Turleri", lty = 10, border = "red") #cizgi turu
pie(table(voice.part), main = "Ses Turleri", col = rainbow(25))
pie(table(voice.part), main = "Ses Turleri", col = heat.colors(8))
pie(table(voice.part), main = "Ses Turleri", col = heat.colors(8),clockwise=T)

# DOT CHART
dotchart(height)
unique(height)
sort(unique(height))
table(height)
dotchart(height, pch = 16)
dotchart(height, pch = 16, pt.cex = 2, color = "darkblue")

