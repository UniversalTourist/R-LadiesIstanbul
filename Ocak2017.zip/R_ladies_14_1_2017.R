#Load the package
library(BayesFactor)

#Coin example
ntoss<-100000
heads<-50350
prop.test(heads,ntoss,p=0.5) #classical approach
proportionBF(heads,ntoss,p=0.5,rscale=1) #bayesian approach

#Create hypothetical populations with known parameters
set.seed(12345)
npop<-100000 #population size
y1<-rnorm(npop,mean=12,sd=3)
y2<-rnorm(npop,mean=10,sd=2)
y3<-2*y1+3*y2+rnorm(npop,mean=0,sd=5)

#Random sampling
nsamp<-100 #sample size
x1<-sample(y1,nsamp,replace=FALSE)
x2<-sample(y1,nsamp,replace=FALSE)
x3<-sample(y2,nsamp,replace=FALSE)

#Display means and standard deviations
cbind(c(mean(x1),mean(x2),mean(x3)),c(sd(x1),sd(x2),sd(x3)))

#One-sample T test
t.test(x1,alternative="two.sided",mu=12,conf.level=0.95) #classical
ttestBF(x1,mu=12,nullInterval=c(-Inf,Inf)) #bayesian
#bt<-ttestBF(x1,mu=12,nullInterval=c(-Inf,0))
#bt[1]/bt[2]

#Two-sample T test
t.test(x1,x2,alternative="two.sided",mu=0,conf.level=0.95,var.equal=TRUE) #classical
ttestBF(x1,x2,mu=0,nullInterval=c(-Inf,Inf)) #bayesian

#One-way ANOVA test
x<-c(x1,x2,x3)
s<-factor(c(rep(1,length(x1)),rep(2,length(x2)),rep(3,length(x3))))
df<-data.frame(x,s)
plot(x~s,data=df)
summary(aov(x~s)) #classical
anovaBF(x~s,data=df) #bayesian

#Regression analysis
select <- sample(npop, nsamp, replace=FALSE) #random selection
x1<-rep(1,nsamp) #intercept/constant variable
x2<-y1[select]
x3<-y2[select]
x4<-y3[select]
df<-data.frame(x1,x2,x3,x4)
ols<-lm(x4~x2+x3,data=df) #classical
bls<-regressionBF(x4~x2+x3,data=df) #bayesian
#bls<-lmBF(x4~x2+x3,data=df) #for a more general use
summary(ols)
plot(bls)

#Sample from the posterior distribution of the best model
pick<-which.max(bls)
simul<-posterior(bls[pick], iterations = 10000)
#simul<-recompute(simul,iterations=10000,thin=1)
summary(simul)
HPDinterval(simul[,1:3],prob=.95) #Credible (not confidence) intervals
#confint(ols,parm =c(2,3),level=.95) #Confidence intervals from OLS
plot(simul[,1:3])
